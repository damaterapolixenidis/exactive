<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="mystyle.css">
<title>Αρχείο σελίδων</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="bootstrap/css/bootstrap-responsive.css" rel="stylesheet">
</head>
<body>
<div class="maindv">
	<div class="cont">
		<div class="tittleheader"><span>tickets</span></div>
		<div class="container">
  <div class="row-fluid">
    <div class="span2">
      test
    </div>
    <div class="span10">
      <a class="atags" target="_blank" href="https://drive.google.com/folderview?id=0ByzScDPxjWBtfkloVkVKSzM2Z0k2UXVLaDF0LW9aQVk2NFkzUWw0cEVCYjZlcEw1WFhoYTQ&usp=sharing"><div class="divtags"><span class="cstag">Αιτήσεις</span></div></a>
				<a class="atags" target="_blavk" href="https://docs.google.com/spreadsheets/d/1d8qgjeEKNm9On1qLhPu9NFJ7CqatMSbMf-iouPAcdbQ/edit#gid=0"><div class="divtags"><span class="cstag">Ιδέες - Εκκρεμότητες</span></div></a>
				<a class="atags" target="_blank" href="http://5.172.194.247/~tickets/prosopiko.html"><div class="divtags"><span class="cstag">Προσωπικό</span></div></a>
				<a class="atags" target="_blank" href="https://docs.google.com/spreadsheets/d/1wFyd4zQvTzdvSN8WBP0Nctu1tlabyE38Pi97oWCUpP0/edit?usp=sharing"><div class="divtags"><span class="cstag">Λίστα Ιστοσελίδων</span></div></a>
				
				<a class="atags" target="_blank" href="https://drive.google.com/folderview?id=0B8uAISNcdqUpaXVBSkl0cjEya3c&usp=sharing"><div class="divtags"><span class="cstag">Σημαντικά Κείμενα</span></div></a>
				<a class="atags" href="https://www.producteev.com/workspace/t/57a452022adaea3555000007" target="_blank"><div id="" class="divtags"><span class="cstag">Τρέχουσες εργασίες</span></div></a>


				<a class="atags" href="https://accounts.google.com/ServiceLogin?service=wise&passive=1209600&continue=https%3A%2F%2Fdocs.google.com%2Fspreadsheets%2Fd%2F1GuMUzHy09Kt7bln5ujvY-sLjEEI7q7wPWlOg4IygTCE%2Fedit&followup=https%3A%2F%2Fdocs.google.com%2Fspreadsheets%2Fd%2F1GuMUzHy09Kt7bln5ujvY-sLjEEI7q7wPWlOg4IygTCE%2Fedit&ltmpl=sheets#identifier" target="_blank"><div id="" class="divtags"><span class="cstag">Κανονισμού</span></div></a>
				<a class="atags" target="_blank" href="https://docs.google.com/spreadsheets/d/1n-jaMQirft_062yjvxXxxUfDov2OnEcj6V9jPOwgXP8/edit?usp=sharing"><div class="divtags"><span class="cstag">Κωδικοί Πελατών</span></div></a>
                
                <a class="atags" target="_blank" href="http://5.172.194.247/~tickets/pros.html"><div class="divtags"><span class="cstag">Υποψήφιο Προσωπικό</span></div></a>
				<a class="atags" target="_blank" href="https://drive.google.com/drive/u/1/folders/0ByzScDPxjWBtfkNfbU9GaDNwOFNXYW9XWjVab254LUZwV0RGSEdyNHdyNExXTkVDMnUxUDA" ><div class="divtags"><span class="cstag">Αγγελίες</span></div></a>
				<a class="atags" target="_blank" href="https://drive.google.com/folderview?id=0B8uAISNcdqUpflJ3NDhvdzd5emhTVm5mVnNBcTdCb0pTZUE0OVhzS1hvSVBVdDNheUJCbWM&usp=sharing" ><div class="divtags"><span class="cstag">Οδηγοί Εργασιών</span></div></a>
				<a class="atags" target="_blank" href="https://docs.google.com/spreadsheets/d/14iBN1EiYFOa0q3F8FNbbaj8XK2YzCdHWrgpwbkzSrtI/edit#gid=0"><div class="divtags"><span class="cstag">ACS αντικαταβολές</span></div></a>

                <a class="atags" target="_blank" href="https://docs.google.com/spreadsheets/d/1_spQMsUWHgPRTV3OFZSJul4VYejSR834h-IFDaUqp60/edit#gid=0"><div class="divtags"><span class="cstag">Media</span></div></a>
                <a class="atags" href="https://drive.google.com/drive/folders/0B8uAISNcdqUpaXVBSkl0cjEya3c" target="_blank"><div id="" class="divtags"><span class="cstag">Έτοιμα Kείμενα</span></div></a>
				<a class="atags" href="https://docs.google.com/spreadsheets/d/1p_4H7KMO_na7p_0kXeoEr-m5_RLPwiNdSF40ScYiClQ/edit#gid=0" target="_blank"><div id="" class="divtags"><span class="cstag">Υποχρεώσεις</span></div></a>
				<a class="atags" href="https://drive.google.com/drive/folders/0B3E0YBWe5oDpd0dRc2dYV1FPWlk" target="_blank"><div id="" class="divtags"><span class="cstag">Κείμενα Τηλεμαρκετιγκ</span></div></a>

                        <a class="atags" href="https://drive.google.com/folderview?id=0B6F7dEjKEAFkTDcxVFI5NWRIUG8&usp=sharing" target="_blank"><div id="" class="divtags"><span class="cstag">Τεχνικές εργασίες</span></div></a>
				<a class="atags" href="https://drive.google.com/drive/u/0/folders/0B8uAISNcdqUpN1ltR01fUFM2V1U" target="_blank"><div id="" class="divtags"><span class="cstag">Σχεδιαστικά προγραμμάτων</span></div></a>
				<a class="atags" href="https://accounts.google.com/ServiceLogin?service=wise&passive=1209600&continue=https%3A%2F%2Fdocs.google.com%2Fspreadsheets%2Fd%2F1nqZrELUHNaXY8UJ8QvLFM59wuygQWzEi6H4xz_FHr9A%2Fedit&followup=https%3A%2F%2Fdocs.google.com%2Fspreadsheets%2Fd%2F1nqZrELUHNaXY8UJ8QvLFM59wuygQWzEi6H4xz_FHr9A%2Fedit&ltmpl=sheets#identifier" target="_blank"><div id="" class="divtags"><span class="cstag">Συστήματα Αμοιβών</span></div></a>
				<a class="atags" href="https://docs.google.com/spreadsheets/d/1JqwJ13vAikxFuehmZzT0-EYyShmeUaLjMs--n6tw1ZQ/edit#gid=0" target="_blank"><div id="" class="divtags"><span class="cstag">Κωδικοί, Emails, Λογαριασμών</span></div></a>
			
				<a class="atags" href="https://docs.google.com/spreadsheets/d/1joHWIunLgaD71hKmEGwPZWO4S7h6gcYIKJ8d6nx7rrk/edit#gid=0" target="_blank"><div id="" class="divtags"><span class="cstag">Σελίδες</span></div></a>
				<a class="atags" href="https://accounts.google.com/ServiceLogin?service=wise&passive=1209600&continue=https%3A%2F%2Fdocs.google.com%2Fspreadsheets%2Fd%2F1QeWl5HYNQgkgKfgjoA-JrN4Dc7y8ZYzbQiutTEYvQ2w%2Fedit&followup=https%3A%2F%2Fdocs.google.com%2Fspreadsheets%2Fd%2F1QeWl5HYNQgkgKfgjoA-JrN4Dc7y8ZYzbQiutTEYvQ2w%2Fedit&ltmpl=sheets#identifier" target="_blank"><div id="" class="divtags"><span class="cstag">Απουσίες</span></div></a>
				<a class="atags" href="https://docs.google.com/spreadsheets/d/1vM7SQb_V-dL8juzcuOQq2az9VsikzhD4n9l3N3vhJIQ/edit#gid=0" target="_blank"><div id="" class="divtags"><span class="cstag">Τιμολόγια εν αναμονή</span></div></a>
				<a class="atags" href="https://drive.google.com/drive/folders/0B8uAISNcdqUpZlpQS1dLdDVTYWc" target="_blank"><div id="" class="divtags"><span class="cstag">Αλλαγές στα προγράμματα</span></div></a>

			
			
				<a class="atags" href="https://drive.google.com/drive/folders/0B3E0YBWe5oDpNjJqT2VkUXJfOFk" target="_blank"><div id="" class="divtags"><span class="cstag">Χρησιμα εγγραφα της εταιρείας</span></div></a>
				<a class="atags" href="https://accounts.google.com/ServiceLogin?service=wise&passive=1209600&continue=https://drive.google.com/drive/folders/0B3E0YBWe5oDpbkJ2UHZIWi1CMFU&followup=https://drive.google.com/drive/folders/0B3E0YBWe5oDpbkJ2UHZIWi1CMFU#identifier" target="_blank"><div id="" class="divtags"><span class="cstag">Κατάλογοι διαφήμισης</span></div></a>
				<a class="atags" href="https://docs.google.com/spreadsheets/d/1hNeyAsgSnlCPg-Z_x-s_68CmWvvhgjKOpGAcVWgEEvI/edit?usp=sharing" target="_blank"><div id="" class="divtags">Facebook !<span class="cstag"></span></div></a>
				<a class="atags" href="https://docs.google.com/document/d/1NUggwFNCzVSZsl1c9o_AhxxC4BiM0hTxDGUp4OvM4Jw/edit" target="_blank"><div id="" class="divtags"><span class="cstag">Λογιστικά ερωτήματα</span></div></a>



				<a class="atags" href="https://docs.google.com/document/d/1W-cj0WVLzwNALeTRAxLZFDpiTlwUk3iFkxu9-CwDFZ4/edit" target="_blank"><div id="" class="divtags"><span class="cstag">Προς κακονισμο</span></div></a>
				<a class="atags" href="" target="_blank"><div id="" class="divtags"><span class="cstag">Αρχειο καταγραφης επισκεψεων η τηλεφωνου</span></div></a>
				<a class="atags" href="https://docs.google.com/spreadsheets/d/1oVhgnd4e22OuMdHGk-qYo7RxrO-xPYM47iv9oN9zW6c/edit?usp=sharing" target="_blank"><div id="" class="divtags"><span class="cstag">Ισοτρικο συνομιλιας με προγραμματιστες</span></div></a>
				<a class="atags" href="https://docs.google.com/spreadsheets/d/1nTgudCjh8jziDx5QoQN_UV6gPpMnipMuQFsmn0PBP_s/edit#gid=0" target="_blank"><div id="" class="divtags"><span class="cstag">Προμηθευτές</span></div></a>
    </div>
			<div class="content">
				
			</div>	
	
				</br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br>
             <div class="container">
             <div class="prosopiko">ΔΗΜΟΣΙΟΓΡΑΦΙΚΑ</div>
				
				<a class="atags" href="https://docs.google.com/spreadsheets/d/1-2P6iNVufkEWZ6w6eW9HmQvYAMTFSgu7hty8ZIX3RkA/edit#gid=0" target="_blank"><div id="" class="divtags"><span class="cstag">EuroAsiaNews</span></div></a>
				<a class="atags" href="https://docs.google.com/spreadsheets/d/1mKSl15dcHgAbDwE899BQ8MXH-ezkkrzXq9plToxio3E/edit#gid=1759125696" target="_blank"><div id="" class="divtags"><span class="cstag">Ελληνικών Ιστοσελίδω</span></div></a>
				<a class="atags" href="" target="_blank"><div id="" class="divtags"><span class="cstag"></span></div></a>
				<a class="atags" href="" target="_blank"><div id="" class="divtags"><span class="cstag"></span></div></a>

			</div>
		</div>
		</div>
		<div class="container">
			<div class="content">

			</div>

		</div>
	</div>
</div>






</body>
</html> 